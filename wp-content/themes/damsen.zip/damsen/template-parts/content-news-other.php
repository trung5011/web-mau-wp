



<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package damsen
 */

?>
<li><i class='fa fa-angle-double-right'></i><a href='<?php the_permalink(); ?>'><?php the_title(); ?></a></li>